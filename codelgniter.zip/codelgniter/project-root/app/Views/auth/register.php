<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Taller CodeIgniter 4</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light py-5">
    <div class="container" style="max-width: 600px;">
        <div class="card shadow-lg border-0 rounded-3">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <i class="bi bi-person-plus-fill text-primary display-4"></i>
                    <h3 class="fw-bold mt-2">Crear Cuenta</h3>
                    <p class="text-muted small">Complete el formulario para registrarse</p>
                </div>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                <li><?= esc($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?= base_url('register/process') ?>" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>

                    <h6 class="fw-bold text-primary mb-3">Datos de acceso</h6>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Usuario</label>
                            <input type="text" name="username" class="form-control" value="<?= old('username') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Contraseña</label>
                        <input type="password" name="password" class="form-control" required minlength="6">
                    </div>

                    <hr>
                    <h6 class="fw-bold text-primary mb-3">Datos personales</h6>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombres</label>
                            <input type="text" name="first_name" class="form-control" value="<?= old('first_name') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Apellidos</label>
                            <input type="text" name="last_name" class="form-control" value="<?= old('last_name') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Teléfono</label>
                        <input type="text" name="phone" class="form-control" value="<?= old('phone') ?>">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Tipo de documento</label>
                            <select name="document_type" class="form-select" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($doc_types as $type): ?>
                                    <option value="<?= $type['id'] ?>"><?= esc($type['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Número de documento</label>
                            <input type="text" name="document_number" class="form-control" value="<?= old('document_number') ?>" required>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Foto de perfil (opcional)</label>
                        <input type="file" name="avatar" class="form-control" accept="image/png, image/jpeg">
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">
                        <i class="bi bi-check-circle me-1"></i> Crear cuenta
                    </button>
                </form>
            </div>
            <div class="card-footer bg-white text-center py-3 border-0">
                <a href="<?= base_url('login') ?>" class="text-decoration-none small">¿Ya tienes cuenta? Inicia sesión</a>
            </div>
        </div>
    </div>
</body>
</html>